<?php

namespace App\Enums;

enum PropertyEnum: string
{
    case ENTIER = 'ENTIER';
    case CHAMBRE = 'CHAMBRE';
    case COLOCATION = 'COLOCATION';

}
