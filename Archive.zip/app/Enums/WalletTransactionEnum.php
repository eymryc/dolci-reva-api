<?php

namespace App\Enums;

enum WalletTransactionEnum: string
{
    case CREDIT = 'CREDIT';
    case DEBIT = 'DEBIT';

}
