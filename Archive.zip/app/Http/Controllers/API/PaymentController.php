<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\PaymentInitializeRequest;
use App\Http\Requests\PaymentVerifyRequest;
use App\Models\Booking;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Services\PaystackService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class PaymentController extends Controller
{
    protected PaystackService $paystackService;

    public function __construct(PaystackService $paystackService)
    {
        $this->paystackService = $paystackService;
    }

    /**
     * Initialize a payment transaction
     *
     * @param PaymentInitializeRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function initialize(PaymentInitializeRequest $request)
    {
        try {
            $user = Auth::user();
            $data = $request->validated();

            // Generate reference
            $reference = $this->paystackService->generateReference();

            // Prepare metadata
            $metadata = [
                'user_id' => $user->id,
                'user_email' => $user->email,
            ];

            // If booking_id is provided, add it to metadata
            if (isset($data['booking_id'])) {
                $booking = Booking::findOrFail($data['booking_id']);
                $metadata['booking_id'] = $booking->id;
                $metadata['booking_reference'] = $booking->booking_reference;
                
                // Use booking amount if not provided
                if (!isset($data['amount'])) {
                    $data['amount'] = $booking->total_price;
                }
            }

            // Initialize transaction with Paystack
            $paymentData = [
                'email' => $data['email'] ?? $user->email,
                'amount' => $data['amount'],
                'reference' => $reference,
                'callback_url' => $data['callback_url'] ?? null,
                'metadata' => $metadata,
                'currency' => $data['currency'] ?? 'XOF',
            ];

            $paystackResponse = $this->paystackService->initializeTransaction($paymentData);

            if ($paystackResponse['status']) {
                return response()->json([
                    'status' => Response::HTTP_OK,
                    'success' => true,
                    'message' => 'Payment initialized successfully',
                    'data' => [
                        'authorization_url' => $paystackResponse['data']['authorization_url'],
                        'access_code' => $paystackResponse['data']['access_code'],
                        'reference' => $paystackResponse['data']['reference'],
                        'public_key' => $this->paystackService->getPublicKey(),
                    ],
                ], Response::HTTP_OK);
            }

            return response()->json([
                'success' => false,
                'message' => 'Failed to initialize payment',
            ], Response::HTTP_BAD_REQUEST);

        } catch (\Exception $e) {
            Log::error('Payment Initialize Error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while initializing payment',
                'error' => $e->getMessage(),
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Verify a payment transaction
     *
     * @param PaymentVerifyRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function verify(PaymentVerifyRequest $request)
    {
        DB::beginTransaction();
        try {
            $reference = $request->input('reference');
            $user = Auth::user();

            // Verify transaction with Paystack
            $paystackResponse = $this->paystackService->verifyTransaction($reference);

            if (!$paystackResponse['status']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Payment verification failed',
                ], Response::HTTP_BAD_REQUEST);
            }

            $transactionData = $paystackResponse['data'];
            $status = $transactionData['status'];
            $amount = $transactionData['amount'] / 100; // Convert from kobo to naira
            $metadata = $transactionData['metadata'] ?? [];

            // Check if transaction was successful
            if ($status === 'success') {
                // Get or create user wallet
                $wallet = Wallet::firstOrCreate(
                    ['user_id' => $user->id],
                    ['balance' => 0]
                );

                // Check if this transaction has already been processed
                $existingTransaction = WalletTransaction::where('reason', 'LIKE', '%' . $reference . '%')
                    ->where('wallet_id', $wallet->id)
                    ->first();

                if ($existingTransaction) {
                    DB::rollBack();
                    return response()->json([
                        'success' => false,
                        'message' => 'This transaction has already been processed',
                    ], Response::HTTP_BAD_REQUEST);
                }

                // Credit wallet
                $wallet->increment('balance', $amount);

                // Create wallet transaction
                $reason = 'Paystack Payment - Reference: ' . $reference;
                if (isset($metadata['booking_id'])) {
                    $reason .= ' - Booking #' . $metadata['booking_id'];
                    
                    // Update booking payment status
                    $booking = Booking::find($metadata['booking_id']);
                    if ($booking) {
                        $booking->update(['payment_status' => 'PAYE']);
                    }
                }

                $wallet->transactions()->create([
                    'type' => 'CREDIT',
                    'amount' => $amount,
                    'reason' => $reason,
                ]);

                DB::commit();

                return response()->json([
                    'status' => Response::HTTP_OK,
                    'success' => true,
                    'message' => 'Payment verified and wallet credited successfully',
                    'data' => [
                        'reference' => $reference,
                        'amount' => $amount,
                        'status' => $status,
                        'wallet_balance' => $wallet->fresh()->balance,
                        'transaction_data' => $transactionData,
                    ],
                ], Response::HTTP_OK);
            }

            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Payment verification failed: ' . $status,
                'data' => [
                    'reference' => $reference,
                    'status' => $status,
                ],
            ], Response::HTTP_BAD_REQUEST);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Payment Verify Error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while verifying payment',
                'error' => $e->getMessage(),
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle Paystack webhook
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function webhook(Request $request)
    {
        try {
            $payload = $request->getContent();
            $signature = $request->header('X-Paystack-Signature');

            // Verify webhook signature
            if (!$this->paystackService->verifyWebhookSignature($payload, $signature)) {
                Log::warning('Invalid Paystack webhook signature');
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid signature',
                ], Response::HTTP_UNAUTHORIZED);
            }

            $event = json_decode($payload, true);

            // Handle different event types
            switch ($event['event']) {
                case 'charge.success':
                    $this->handleSuccessfulCharge($event['data']);
                    break;

                case 'charge.failed':
                    $this->handleFailedCharge($event['data']);
                    break;

                case 'transfer.success':
                    $this->handleSuccessfulTransfer($event['data']);
                    break;

                default:
                    Log::info('Unhandled Paystack webhook event: ' . $event['event']);
            }

            return response()->json([
                'success' => true,
                'message' => 'Webhook processed successfully',
            ], Response::HTTP_OK);

        } catch (\Exception $e) {
            Log::error('Paystack Webhook Error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while processing webhook',
                'error' => $e->getMessage(),
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handle successful charge event
     *
     * @param array $data
     * @return void
     */
    private function handleSuccessfulCharge(array $data): void
    {
        DB::beginTransaction();
        try {
            $reference = $data['reference'];
            $amount = $data['amount'] / 100; // Convert from kobo
            $metadata = $data['metadata'] ?? [];
            $customerEmail = $data['customer']['email'] ?? null;

            // Find user by email or metadata
            $userId = $metadata['user_id'] ?? null;
            if (!$userId && $customerEmail) {
                $user = \App\Models\User::where('email', $customerEmail)->first();
                $userId = $user?->id;
            }

            if (!$userId) {
                Log::warning('Could not find user for Paystack charge: ' . $reference);
                DB::rollBack();
                return;
            }

            // Get or create wallet
            $wallet = Wallet::firstOrCreate(
                ['user_id' => $userId],
                ['balance' => 0]
            );

            // Check if already processed
            $existingTransaction = WalletTransaction::where('reason', 'LIKE', '%' . $reference . '%')
                ->where('wallet_id', $wallet->id)
                ->first();

            if ($existingTransaction) {
                Log::info('Paystack charge already processed: ' . $reference);
                DB::rollBack();
                return;
            }

            // Credit wallet
            $wallet->increment('balance', $amount);

            // Create transaction
            $reason = 'Paystack Payment - Reference: ' . $reference;
            if (isset($metadata['booking_id'])) {
                $reason .= ' - Booking #' . $metadata['booking_id'];
                
                // Update booking payment status
                $booking = Booking::find($metadata['booking_id']);
                if ($booking) {
                    $booking->update(['payment_status' => 'PAYE']);
                }
            }

            $wallet->transactions()->create([
                'type' => 'CREDIT',
                'amount' => $amount,
                'reason' => $reason,
            ]);

            DB::commit();
            Log::info('Paystack charge processed successfully: ' . $reference);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error handling successful charge: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Handle failed charge event
     *
     * @param array $data
     * @return void
     */
    private function handleFailedCharge(array $data): void
    {
        $reference = $data['reference'];
        $metadata = $data['metadata'] ?? [];

        // Update booking payment status if applicable
        if (isset($metadata['booking_id'])) {
            $booking = Booking::find($metadata['booking_id']);
            if ($booking) {
                $booking->update(['payment_status' => 'ECHEC']);
            }
        }

        Log::info('Paystack charge failed: ' . $reference);
    }

    /**
     * Handle successful transfer event
     *
     * @param array $data
     * @return void
     */
    private function handleSuccessfulTransfer(array $data): void
    {
        // Handle withdrawal/transfer success
        Log::info('Paystack transfer successful: ' . ($data['reference'] ?? 'N/A'));
    }
}

