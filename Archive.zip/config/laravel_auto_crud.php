<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Fallback Models Path
    |--------------------------------------------------------------------------
    |
    | This value is the fallback path of your models, which will be used when you
    | don't use --model-path option.
    |
    */
    'fallback_models_path' => 'app/Models/',
];
